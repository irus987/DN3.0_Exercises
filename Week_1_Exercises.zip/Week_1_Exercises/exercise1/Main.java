package exercise1;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        InventoryManagementSystem ims = new InventoryManagementSystem();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nInventory Management System");
            System.out.println("1. Add Product");
            System.out.println("2. Update Product");
            System.out.println("3. Delete Product");
            System.out.println("4. View Product");
            System.out.println("5. View All Products");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  

            switch (choice) {
                case 1:
                    addProduct(ims, scanner);
                    break;
                case 2:
                    updateProduct(ims, scanner);
                    break;
                case 3:
                    deleteProduct(ims, scanner);
                    break;
                case 4:
                    viewProduct(ims, scanner);
                    break;
                case 5:
                    ims.printInventory();
                    break;
                case 6:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addProduct(InventoryManagementSystem ims, Scanner scanner) {
        System.out.print("Enter Product ID: ");
        String productId = scanner.nextLine();
        System.out.print("Enter Product Name: ");
        String productName = scanner.nextLine();
        System.out.print("Enter Quantity: ");
        int quantity = scanner.nextInt();
        System.out.print("Enter Price: ");
        double price = scanner.nextDouble();
        scanner.nextLine();  

        Product product = new Product(productId, productName, quantity, price);
        ims.addProduct(product);
        System.out.println("Product added successfully.");
    }

    private static void updateProduct(InventoryManagementSystem ims, Scanner scanner) {
        System.out.print("Enter Product ID to update: ");
        String productId = scanner.nextLine();

        if (ims.getProduct(productId) != null) {
            System.out.print("Enter New Product Name: ");
            String productName = scanner.nextLine();
            System.out.print("Enter New Quantity: ");
            int quantity = scanner.nextInt();
            System.out.print("Enter New Price: ");
            double price = scanner.nextDouble();
            scanner.nextLine();  

            Product updatedProduct = new Product(productId, productName, quantity, price);
            ims.updateProduct(productId, updatedProduct);
            System.out.println("Product updated successfully.");
        } else {
            System.out.println("Product not found!");
        }
    }

    private static void deleteProduct(InventoryManagementSystem ims, Scanner scanner) {
        System.out.print("Enter Product ID to delete: ");
        String productId = scanner.nextLine();
        ims.deleteProduct(productId);
        System.out.println("Product deleted successfully.");
    }

    private static void viewProduct(InventoryManagementSystem ims, Scanner scanner) {
        System.out.print("Enter Product ID to view: ");
        String productId = scanner.nextLine();
        Product product = ims.getProduct(productId);
        if (product != null) {
            System.out.println(product);
        } else {
            System.out.println("Product not found!");
        }
    }
}
