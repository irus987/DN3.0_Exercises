package exercise2;
public class Main {
    public static void main(String[] args) {
        Product[] products = {
            new Product("1", "Laptop", "Electronics"),
            new Product("2", "Smartphone", "Electronics"),
            new Product("3", "Table", "Furniture")
        };

        System.out.println("Linear Search Result:");
        Product result = Search.linearSearch(products, "2");
        if (result != null) {
            System.out.println(result);
        } else {
            System.out.println("Product not found!");
        }

        System.out.println("\nBinary Search Result:");
        result = Search.binarySearch(products, "3");
        if (result != null) {
            System.out.println(result);
        } else {
            System.out.println("Product not found!");
        }
    }
}

