package exercise2;
import java.util.Arrays;

public class Search {
    public static Product linearSearch(Product[] products, String targetId) {
        for (Product product : products) {
            if (product.getProductId().equals(targetId)) {
                return product;
            }
        }
        return null;
    }

    public static Product binarySearch(Product[] products, String targetId) {
        int left = 0;
        int right = products.length - 1;

        Arrays.sort(products, (p1, p2) -> p1.getProductId().compareTo(p2.getProductId()));

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int compareResult = products[mid].getProductId().compareTo(targetId);

            if (compareResult == 0) {
                return products[mid];
            }
            if (compareResult < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }
}

