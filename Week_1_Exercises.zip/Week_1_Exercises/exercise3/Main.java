package exercise3;

public class Main {
    public static void main(String[] args) {
        Order[] orders = {
            new Order("1", "Alice", 250.0),
            new Order("2", "Bob", 150.0),
            new Order("3", "Charlie", 300.0)
        };

        System.out.println("Orders before sorting:");
        for (Order order : orders) {
            System.out.println(order);
        }

        System.out.println("\nOrders after Bubble Sort:");
        Sort.bubbleSort(orders);
        for (Order order : orders) {
            System.out.println(order);
        }

        // Reset the orders array
        orders = new Order[]{
            new Order("1", "Alice", 250.0),
            new Order("2", "Bob", 150.0),
            new Order("3", "Charlie", 300.0)
        };

        System.out.println("\nOrders after Quick Sort:");
        Sort.quickSort(orders, 0, orders.length - 1);
        for (Order order : orders) {
            System.out.println(order);
        }
    }
}
