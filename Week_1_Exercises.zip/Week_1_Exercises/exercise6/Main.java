package exercise6;

public class Main {
    public static void main(String[] args) {
        Book[] books = {
            new Book("1", "The Great Gatsby", "F. Scott Fitzgerald"),
            new Book("2", "1984", "George Orwell"),
            new Book("3", "To Kill a Mockingbird", "Harper Lee")
        };

        System.out.println("Linear Search Result:");
        Book result = Search.linearSearch(books, "1984");
        if (result != null) {
            System.out.println(result);
        } else {
            System.out.println("Book not found!");
        }

        System.out.println("\nBinary Search Result:");
        result = Search.binarySearch(books, "The Great Gatsby");
        if (result != null) {
            System.out.println(result);
        } else {
            System.out.println("Book not found!");
        }
    }
}
