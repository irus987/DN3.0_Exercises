package exercise7;

public class FinancialForecasting {
    public static double predictFutureValue(double initialValue, double growthRate, int years) {
        if (years == 0) {
            return initialValue;
        }
        return predictFutureValue(initialValue * (1 + growthRate), growthRate, years - 1);
    }

    public static double predictFutureValueOptimized(double initialValue, double growthRate, int years) {
        return initialValue * Math.pow(1 + growthRate, years);
    }
}
