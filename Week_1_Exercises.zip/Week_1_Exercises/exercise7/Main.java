package exercise7;

public class Main {
    public static void main(String[] args) {
        double initialValue = 1000;
        double growthRate = 0.05;
        int years = 10;

        double futureValueRecursive = FinancialForecasting.predictFutureValue(initialValue, growthRate, years);
        double futureValueOptimized = FinancialForecasting.predictFutureValueOptimized(initialValue, growthRate, years);

        System.out.println("Future Value (Recursive): " + futureValueRecursive);
        System.out.println("Future Value (Optimized): " + futureValueOptimized);
    }
}
