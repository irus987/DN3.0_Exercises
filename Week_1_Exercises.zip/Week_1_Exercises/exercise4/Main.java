package exercise4;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(10);
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nEmployee Management System");
            System.out.println("1. Add Employee");
            System.out.println("2. Search Employee");
            System.out.println("3. Traverse Employees");
            System.out.println("4. Delete Employee");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addEmployee(ems, scanner);
                    break;
                case 2:
                    searchEmployee(ems, scanner);
                    break;
                case 3:
                    ems.traverseEmployees();
                    break;
                case 4:
                    deleteEmployee(ems, scanner);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addEmployee(EmployeeManagementSystem ems, Scanner scanner) {
        System.out.print("Enter Employee ID: ");
        String employeeId = scanner.nextLine();
        System.out.print("Enter Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Position: ");
        String position = scanner.nextLine();
        System.out.print("Enter Salary: ");
        double salary = scanner.nextDouble();
        scanner.nextLine();

        Employee employee = new Employee(employeeId, name, position, salary);
        ems.addEmployee(employee);
        System.out.println("Employee added successfully.");
    }

    private static void searchEmployee(EmployeeManagementSystem ems, Scanner scanner) {
        System.out.print("Enter Employee ID to search: ");
        String employeeId = scanner.nextLine();
        Employee employee = ems.searchEmployee(employeeId);
        if (employee != null) {
            System.out.println(employee);
        } else {
            System.out.println("Employee not found!");
        }
    }

    private static void deleteEmployee(EmployeeManagementSystem ems, Scanner scanner) {
        System.out.print("Enter Employee ID to delete: ");
        String employeeId = scanner.nextLine();
        ems.deleteEmployee(employeeId);
    }
}
