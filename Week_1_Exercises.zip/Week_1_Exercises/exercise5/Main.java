package exercise5;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        SinglyLinkedList taskList = new SinglyLinkedList();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nTask Management System");
            System.out.println("1. Add Task");
            System.out.println("2. Search Task");
            System.out.println("3. Traverse Tasks");
            System.out.println("4. Delete Task");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addTask(taskList, scanner);
                    break;
                case 2:
                    searchTask(taskList, scanner);
                    break;
                case 3:
                    taskList.traverseTasks();
                    break;
                case 4:
                    deleteTask(taskList, scanner);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addTask(SinglyLinkedList taskList, Scanner scanner) {
        System.out.print("Enter Task ID: ");
        String taskId = scanner.nextLine();
        System.out.print("Enter Task Name: ");
        String taskName = scanner.nextLine();
        System.out.print("Enter Status: ");
        String status = scanner.nextLine();

        Task task = new Task(taskId, taskName, status);
        taskList.addTask(task);
        System.out.println("Task added successfully.");
    }

    private static void searchTask(SinglyLinkedList taskList, Scanner scanner) {
        System.out.print("Enter Task ID to search: ");
        String taskId = scanner.nextLine();
        Task task = taskList.searchTask(taskId);
        if (task != null) {
            System.out.println(task);
        } else {
            System.out.println("Task not found!");
        }
    }

    private static void deleteTask(SinglyLinkedList taskList, Scanner scanner) {
        System.out.print("Enter Task ID to delete: ");
        String taskId = scanner.nextLine();
        taskList.deleteTask(taskId);
        System.out.println("Task deleted successfully.");
    }
}
